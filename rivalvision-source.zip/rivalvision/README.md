# Rival Vision – Player & Tag Hider (Fabric 1.20.1, client-side)

Oculta jogadores e/ou nametags **somente na renderização local**. Não toca em pacotes, servidor ou dados de outros jogadores.
Funciona em multiplayer sem instalar nada no servidor.

## Instalação
1. Instale o Fabric Loader (1.20.1) e coloque a **Fabric API** na pasta `mods`.
2. Coloque `rivalvision-1.0.0.jar` na pasta `mods`.
3. Abra o jogo.

## Compilar (PC)
Java 17 + Gradle 8.5:  `gradle wrapper --gradle-version 8.5 && ./gradlew build`  → `build/libs/rivalvision-1.0.0.jar`
Pelo celular: use o GitHub Actions (workflow nas instruções do chat).

## Uso
- **V**: abre o menu (abas Rivais / Ocultos / Tags / Opções). **Z**: liga/desliga ocultação de jogadores. **X**: liga/desliga ocultação de tags. Todas reconfiguráveis em Controles > Rival Vision.
- Menu: digite o nome, toque em Adicionar (ou Enter); use a pesquisa para filtrar; toque no "x" da linha para remover.
- Comandos: `/rv rival add <nome>`, `/rv hide add <nome>`, `/rv tag add <nome>`, `/rv <lista> remove <nome>`, `/rv <lista> list`.
- Config: `config/rivalvision.json` (salva automaticamente a cada alteração).

## Prioridade
1. Rivais: corpo e tag sempre visíveis.
2. Lista de ocultos: jogador totalmente invisível (modelo, armadura, itens, sombra, tag).
3. Lista de tags: personagem visível, tag (nome + vida do placar) oculta.
4. Não cadastrados: normais.
Opções extras (aba Opções): "Ocultar TODOS menos rivais" e "Tags de TODOS menos rivais".
Você nunca oculta a si mesmo.

## Como funciona (e custo)
- `EntityRenderDispatcher.shouldRender` (HEAD): para jogadores ocultos retorna false → o jogo pula a entidade inteira (também economiza FPS).
- `EntityRenderer.renderLabelIfPresent` e `PlayerEntityRenderer.renderLabelIfPresent` (HEAD): cancelam nome e placar acima da cabeça.
- Decisão em cache por UUID (HashMap), invalidada só quando a config muda; lookup O(1) por nome em minúsculas.
- Único trabalho por tick: ler 3 teclas. Sem loops sobre jogadores. Nenhuma alocação por frame.
- Mixins com `require = 0`: se um alvo não existir, o recurso fica inativo em silêncio em vez de crashar.

## Limitações
- Jogadores ocultos continuam existindo: podem ser atingidos, colidir e aparecer na tab list/chat. É só visual.
- Tags feitas por servidor com outras entidades (armor stands/hologramas/display entities) não são jogadores e não são afetadas.
- O nome comparado é o do perfil (login real), não apelidos.
- Código ainda não compilado/testado no jogo.
