package com.rivalvision;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;

/**
 * Decide, por jogador, se o corpo e/ou a tag devem ser ocultados.
 * Prioridade: 1) rival (sempre visível)  2) lista de ocultos  3) lista de tags  4) normal.
 * O resultado fica em cache por UUID (sem alocação por frame) e é invalidado quando a config muda.
 */
public final class PlayerFilter {
    private static final int BODY = 1, TAG = 2;
    private static final HashMap<UUID, Integer> CACHE = new HashMap<>();
    private static int cacheVersion = -1;

    private PlayerFilter() {}

    public static boolean hideBody(PlayerEntity p) { return (mask(p) & BODY) != 0; }
    public static boolean hideTag(PlayerEntity p) { return (mask(p) & TAG) != 0; }

    public static void clear() { CACHE.clear(); }

    private static int mask(PlayerEntity p) {
        if (p == MinecraftClient.getInstance().player) return 0; // nunca oculta você mesmo
        if (cacheVersion != RivalConfig.version) {
            CACHE.clear();
            cacheVersion = RivalConfig.version;
        }
        Integer cached = CACHE.get(p.getUuid());
        if (cached != null) return cached;

        RivalConfig c = RivalConfig.get();
        String n = p.getGameProfile().getName().toLowerCase(Locale.ROOT);
        int m = 0;
        if (!c.isRival(n)) {
            if (c.hidePlayersEnabled && (c.hideAllExceptRivals || c.isHidden(n))) m |= BODY;
            if (c.hideTagsEnabled && (c.hideAllTagsExceptRivals || c.isTagHidden(n))) m |= TAG;
        }
        CACHE.put(p.getUuid(), m);
        return m;
    }
}
