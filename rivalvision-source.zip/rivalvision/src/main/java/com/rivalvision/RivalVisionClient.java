package com.rivalvision;

import com.rivalvision.command.RivalCommand;
import com.rivalvision.gui.RivalScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class RivalVisionClient implements ClientModInitializer {
    private static KeyBinding playersKey, tagsKey, menuKey;

    @Override
    public void onInitializeClient() {
        RivalConfig.load();

        playersKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.rivalvision.players",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.rivalvision"));
        tagsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.rivalvision.tags",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, "key.categories.rivalvision"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.rivalvision.menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.rivalvision"));

        // Único trabalho por tick: consultar 3 teclas (custo desprezível). Nada de loops sobre jogadores.
        ClientTickEvents.END_CLIENT_TICK.register(RivalVisionClient::onTick);
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> PlayerFilter.clear());
        RivalCommand.register();
    }

    private static void onTick(MinecraftClient mc) {
        RivalConfig c = RivalConfig.get();
        while (playersKey.wasPressed()) {
            c.hidePlayersEnabled = !c.hidePlayersEnabled;
            c.changed();
            notify(mc, "rivalvision.msg.players", c.hidePlayersEnabled);
        }
        while (tagsKey.wasPressed()) {
            c.hideTagsEnabled = !c.hideTagsEnabled;
            c.changed();
            notify(mc, "rivalvision.msg.tags", c.hideTagsEnabled);
        }
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new RivalScreen(null));
        }
    }

    private static void notify(MinecraftClient mc, String key, boolean on) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.translatable(key,
                    Text.translatable(on ? "rivalvision.on" : "rivalvision.off")), true);
        }
    }
}
