package com.rivalvision.gui;

import com.rivalvision.RivalConfig;
import com.rivalvision.RivalConfig.ListType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Abas: Rivais | Ocultos | Tags | Opções. Cada aba de lista tem campo de nome + Adicionar, pesquisa,
 * lista rolável e botão × para remover. Tudo é salvo automaticamente.
 */
public class RivalScreen extends Screen {
    private static final int M = 8, ROW_H = 14;
    private static final String[] TAB_KEYS = {"rivals", "hidden", "tags", "options"};

    private final Screen parent;
    private int tab;
    private TextFieldWidget nameField, searchField;
    private final List<String> view = new ArrayList<>();
    private int scroll, listX, listY, listW, listH;
    private Text status = Text.empty();

    public RivalScreen(Screen parent) {
        super(Text.literal("Rival Vision"));
        this.parent = parent;
    }

    private ListType type() { return ListType.values()[tab]; }

    @Override
    protected void init() {
        nameField = null;
        searchField = null;

        int tw = (width - 2 * M - 9) / 4;
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.translatable("rivalvision.tab." + TAB_KEYS[i]), btn -> {
                tab = idx; scroll = 0; status = Text.empty(); clearChildren(); init();
            }).dimensions(M + i * (tw + 3), 6, tw, 18).build();
            b.active = i != tab;
            addDrawableChild(b);
        }

        addDrawableChild(ButtonWidget.builder(Text.translatable("rivalvision.done"), b -> close())
                .dimensions(width / 2 - 50, height - 24, 100, 20).build());

        if (tab < 3) initListTab(); else initOptionsTab();
    }

    private void initListTab() {
        int addW = Math.min(80, width / 4);
        String hint = Text.translatable("rivalvision.field.name").getString();
        nameField = new TextFieldWidget(textRenderer, M, 28, width - 2 * M - addW - 4, 18, Text.translatable("rivalvision.field.name"));
        nameField.setMaxLength(17);
        nameField.setTextPredicate(s -> s.matches("[A-Za-z0-9_.]*"));
        nameField.setSuggestion(hint);
        nameField.setChangedListener(s -> nameField.setSuggestion(s.isEmpty() ? hint : null));
        addDrawableChild(nameField);

        addDrawableChild(ButtonWidget.builder(Text.translatable("rivalvision.add"), b -> doAdd())
                .dimensions(width - M - addW, 28, addW, 18).build());

        String shint = Text.translatable("rivalvision.field.search").getString();
        searchField = new TextFieldWidget(textRenderer, M, 50, width - 2 * M, 18, Text.translatable("rivalvision.field.search"));
        searchField.setMaxLength(32);
        searchField.setSuggestion(shint);
        searchField.setChangedListener(s -> {
            searchField.setSuggestion(s.isEmpty() ? shint : null);
            scroll = 0;
            rebuild();
        });
        addDrawableChild(searchField);

        listX = M; listY = 72; listW = width - 2 * M;
        listH = Math.max(28, height - 38 - listY);
        rebuild();
    }

    private void initOptionsTab() {
        RivalConfig c = RivalConfig.get();
        int cw = (width - 2 * M - 4) / 2;
        opt(0, cw, "players", c.hidePlayersEnabled, v -> c.hidePlayersEnabled = v);
        opt(1, cw, "tags", c.hideTagsEnabled, v -> c.hideTagsEnabled = v);
        opt(2, cw, "allplayers", c.hideAllExceptRivals, v -> c.hideAllExceptRivals = v);
        opt(3, cw, "alltags", c.hideAllTagsExceptRivals, v -> c.hideAllTagsExceptRivals = v);
    }

    private void opt(int i, int cw, String key, boolean init, Consumer<Boolean> setter) {
        int x = M + (i % 2) * (cw + 4);
        int y = 30 + (i / 2) * 22;
        addDrawableChild(CyclingButtonWidget.onOffBuilder(init).build(x, y, cw, 20,
                Text.translatable("rivalvision.opt." + key), (b, v) -> { setter.accept(v); RivalConfig.get().changed(); }));
    }

    private void rebuild() {
        view.clear();
        String f = searchField == null ? "" : searchField.getText().toLowerCase(Locale.ROOT);
        for (String s : RivalConfig.get().list(type())) {
            if (f.isEmpty() || s.toLowerCase(Locale.ROOT).contains(f)) view.add(s);
        }
        clampScroll();
    }

    private void clampScroll() {
        int max = Math.max(0, view.size() * ROW_H - listH);
        scroll = Math.max(0, Math.min(scroll, max));
    }

    private void doAdd() {
        if (nameField == null) return;
        String n = nameField.getText().trim();
        if (n.isEmpty() || !n.matches("[A-Za-z0-9_.]{1,17}")) {
            status = Text.translatable("rivalvision.status.invalid").formatted(Formatting.RED);
            return;
        }
        boolean ok = RivalConfig.get().add(type(), n);
        status = Text.translatable(ok ? "rivalvision.status.added" : "rivalvision.status.exists", n)
                .formatted(ok ? Formatting.GREEN : Formatting.YELLOW);
        if (ok) nameField.setText("");
        rebuild();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, delta);
        if (tab < 3) {
            drawList(ctx, mouseX, mouseY);
        } else {
            ctx.drawTextWrapped(textRenderer, Text.translatable("rivalvision.info"), M, 80, width - 2 * M, 0xFFBBBBBB);
        }
        ctx.drawTextWithShadow(textRenderer, status, M, height - 36, 0xFFFFFFFF);
    }

    private void drawList(DrawContext ctx, int mouseX, int mouseY) {
        ctx.fill(listX, listY, listX + listW, listY + listH, 0x99000000);
        if (view.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("rivalvision.empty"),
                    listX + listW / 2, listY + listH / 2 - 4, 0xFF888888);
            return;
        }
        ctx.enableScissor(listX, listY, listX + listW, listY + listH);
        for (int i = 0; i < view.size(); i++) {
            int ry = listY + i * ROW_H - scroll;
            if (ry + ROW_H < listY || ry > listY + listH) continue;
            boolean hover = mouseX >= listX && mouseX < listX + listW && mouseY >= ry && mouseY < ry + ROW_H
                    && mouseY >= listY && mouseY < listY + listH;
            if (hover) ctx.fill(listX, ry, listX + listW, ry + ROW_H, 0x33FFFFFF);
            ctx.drawTextWithShadow(textRenderer, view.get(i), listX + 4, ry + 3, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, "x", listX + listW - 12, ry + 3, hover ? 0xFFFF5555 : 0xFFAA4444);
        }
        ctx.disableScissor();

        int content = view.size() * ROW_H;
        if (content > listH) {
            int barH = Math.max(8, listH * listH / content);
            int barY = listY + (listH - barH) * scroll / (content - listH);
            ctx.fill(listX + listW - 2, barY, listX + listW, barY + barH, 0xAAFFFFFF);
        }
    }

    private boolean inList(double mx, double my) {
        return tab < 3 && mx >= listX && mx < listX + listW && my >= listY && my < listY + listH;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && inList(mouseX, mouseY) && mouseX >= listX + listW - 18) {
            int row = (int) ((mouseY - listY + scroll) / ROW_H);
            if (row >= 0 && row < view.size()) {
                String n = view.get(row);
                RivalConfig.get().remove(type(), n);
                status = Text.translatable("rivalvision.status.removed", n);
                rebuild();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (inList(mouseX, mouseY)) {
            scroll -= (int) (amount * ROW_H * 2);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)
                && nameField != null && nameField.isFocused()) {
            doAdd();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() { client.setScreen(parent); }
}
