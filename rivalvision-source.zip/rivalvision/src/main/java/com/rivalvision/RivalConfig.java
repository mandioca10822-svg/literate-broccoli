package com.rivalvision;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** config/rivalvision.json — salvo automaticamente a cada alteração. */
public class RivalConfig {
    public enum ListType { RIVALS, HIDDEN, TAGS }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("rivalvision.json");
    private static RivalConfig instance = new RivalConfig();

    /** Incrementa a cada mudança; o cache de decisões se invalida comparando este valor. */
    public static int version = 0;

    public boolean hidePlayersEnabled = true;
    public boolean hideTagsEnabled = true;
    public boolean hideAllExceptRivals = false;
    public boolean hideAllTagsExceptRivals = false;

    public List<String> rivals = new ArrayList<>();
    public List<String> hidden = new ArrayList<>();
    public List<String> tagHidden = new ArrayList<>();

    private transient Set<String> rivalSet = new HashSet<>();
    private transient Set<String> hiddenSet = new HashSet<>();
    private transient Set<String> tagSet = new HashSet<>();

    public static RivalConfig get() { return instance; }

    public static void load() {
        if (Files.exists(PATH)) {
            try (Reader r = Files.newBufferedReader(PATH)) {
                RivalConfig c = GSON.fromJson(r, RivalConfig.class);
                if (c != null) instance = c;
            } catch (IOException | JsonParseException e) {
                System.err.println("[RivalVision] Config inválida, usando padrão: " + e);
            }
        }
        RivalConfig c = instance;
        if (c.rivals == null) c.rivals = new ArrayList<>();
        if (c.hidden == null) c.hidden = new ArrayList<>();
        if (c.tagHidden == null) c.tagHidden = new ArrayList<>();
        c.rebuild();
    }

    public List<String> list(ListType t) {
        return switch (t) {
            case RIVALS -> rivals;
            case HIDDEN -> hidden;
            case TAGS -> tagHidden;
        };
    }

    /** @return false se já existia (ignorando maiúsculas). */
    public boolean add(ListType t, String name) {
        List<String> l = list(t);
        for (String s : l) if (s.equalsIgnoreCase(name)) return false;
        l.add(name);
        l.sort(String.CASE_INSENSITIVE_ORDER);
        changed();
        return true;
    }

    public boolean remove(ListType t, String name) {
        boolean r = list(t).removeIf(s -> s.equalsIgnoreCase(name));
        if (r) changed();
        return r;
    }

    public boolean isRival(String lower) { return rivalSet.contains(lower); }
    public boolean isHidden(String lower) { return hiddenSet.contains(lower); }
    public boolean isTagHidden(String lower) { return tagSet.contains(lower); }

    /** Recalcula os conjuntos (lookup O(1)), invalida o cache e salva. */
    public void changed() {
        rebuild();
        save();
    }

    private void rebuild() {
        rivalSet = lower(rivals);
        hiddenSet = lower(hidden);
        tagSet = lower(tagHidden);
        version++;
    }

    private static Set<String> lower(List<String> l) {
        Set<String> s = new HashSet<>();
        for (String n : l) s.add(n.toLowerCase(Locale.ROOT));
        return s;
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(PATH)) {
            GSON.toJson(instance, w);
        } catch (IOException e) {
            System.err.println("[RivalVision] Falha ao salvar config: " + e);
        }
    }
}
