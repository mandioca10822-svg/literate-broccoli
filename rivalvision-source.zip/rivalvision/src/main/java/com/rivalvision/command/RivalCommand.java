package com.rivalvision.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.rivalvision.RivalConfig;
import com.rivalvision.RivalConfig.ListType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** /rv rival|hide|tag add|remove <nome>  e  /rv rival|hide|tag list  (atalho útil em telas pequenas). */
public final class RivalCommand {
    private RivalCommand() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("rv");
            for (ListType t : ListType.values()) {
                String lit = switch (t) { case RIVALS -> "rival"; case HIDDEN -> "hide"; case TAGS -> "tag"; };
                root.then(ClientCommandManager.literal(lit)
                    .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
                            String n = StringArgumentType.getString(ctx, "name");
                            boolean ok = RivalConfig.get().add(t, n);
                            ctx.getSource().sendFeedback(Text.translatable(
                                    ok ? "rivalvision.status.added" : "rivalvision.status.exists", n)
                                    .formatted(ok ? Formatting.GREEN : Formatting.YELLOW));
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
                            String n = StringArgumentType.getString(ctx, "name");
                            RivalConfig.get().remove(t, n);
                            ctx.getSource().sendFeedback(Text.translatable("rivalvision.status.removed", n));
                            return 1;
                        })))
                    .then(ClientCommandManager.literal("list").executes(ctx -> {
                        String joined = String.join(", ", RivalConfig.get().list(t));
                        ctx.getSource().sendFeedback(Text.translatable("rivalvision.cmd.list", lit,
                                joined.isEmpty() ? Text.translatable("rivalvision.cmd.none").getString() : joined));
                        return 1;
                    })));
            }
            dispatcher.register(root);
        });
    }
}
