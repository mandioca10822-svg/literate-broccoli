package com.rivalvision.mixin;

import com.rivalvision.PlayerFilter;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    /**
     * Quando false, o WorldRenderer pula a entidade inteira: modelo, armadura, itens, sombra, fogo e tag.
     * Só afeta o desenho local; a entidade continua existindo normalmente para o jogo e para o servidor.
     */
    @Inject(method = "shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void rv$hideBody(Entity entity, Frustum frustum, double x, double y, double z,
                             CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof PlayerEntity p && PlayerFilter.hideBody(p)) cir.setReturnValue(false);
    }
}
